package com.example.calculator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.calculator.ui.theme.CalculatorTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CalculatorTheme {
                CalculatorScreen()
            }
        }
    }
}

@Composable
fun CalculatorScreen() {
    val buttonSize = dimensionResource(id = R.dimen.button_size)
    val buttonPadding = dimensionResource(id = R.dimen.padding)

    val lightGrayBackground = colorResource(id = R.color.light_gray)
    val operationColor = Color.Black
    val resultColor = Color.Gray.copy(alpha = 0.7f) // Color gris no tan claro

    // Contenedor general
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(buttonPadding)
            .background(lightGrayBackground),
        verticalArrangement = Arrangement.spacedBy(buttonPadding),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Contenedor para la visualización de cálculos y resultados
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.5f) // Ocupa espacio hasta que el usuario lo llene
                .padding(buttonPadding),
            horizontalAlignment = Alignment.End // Ajusta el texto a la derecha
        ) {
            // Línea para mostrar operaciones
            Text(
                text = "142+32+12+69", // Este valor se debería actualizar dinámicamente
                fontSize = 32.sp,
                color = operationColor,
                lineHeight = 32.sp // Ajusta el espacio entre las líneas
            )
            // Espacio entre las líneas
            Spacer(modifier = Modifier.height(8.dp)) // Añadir espacio entre operaciones y resultado
            // Línea para mostrar el resultado
            Text(
                text = "259", // Este valor se debería actualizar dinámicamente
                fontSize = 32.sp,
                color = resultColor
            )
        }

        // Añadir la línea divisoria
        HorizontalDivider(
            modifier = Modifier
                .padding(vertical = 8.dp) // Espacio alrededor de la línea
                .align(Alignment.CenterHorizontally),
            thickness = 2.dp,
            color = colorResource(id = R.color.SkyBlue)
        )

        // Contenedor de botones
        Column(
            verticalArrangement = Arrangement.spacedBy(buttonPadding),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Fila 1
            Row(
                modifier = Modifier.padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(buttonPadding)
            ) {
                CalcButton(text = "C", modifier = Modifier.size(buttonSize), color = colorResource(id = R.color.DeleteAllcolor))
                CalcButton(text = "(", modifier = Modifier.size(buttonSize), color = colorResource(id = R.color.ParenthesisColor))
                CalcButton(text = ")", modifier = Modifier.size(buttonSize), color = colorResource(id = R.color.ParenthesisColor))
                CalcButton(text = "/", modifier = Modifier.size(buttonSize), color = colorResource(id = R.color.OperatorsColor))
            }
            // Fila 2
            Row(
                modifier = Modifier.padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(buttonPadding)
            ) {
                CalcButton(text = "7", modifier = Modifier.size(buttonSize))
                CalcButton(text = "8", modifier = Modifier.size(buttonSize))
                CalcButton(text = "9", modifier = Modifier.size(buttonSize))
                CalcButton(text = "*", modifier = Modifier.size(buttonSize), color = colorResource(id = R.color.OperatorsColor))
            }
            // Fila 3
            Row(
                modifier = Modifier.padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(buttonPadding)
            ) {
                CalcButton(text = "4", modifier = Modifier.size(buttonSize))
                CalcButton(text = "5", modifier = Modifier.size(buttonSize))
                CalcButton(text = "6", modifier = Modifier.size(buttonSize))
                CalcButton(text = "+", modifier = Modifier.size(buttonSize), color = colorResource(id = R.color.OperatorsColor))
            }
            // Fila 4
            Row(
                modifier = Modifier.padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(buttonPadding)
            ) {
                CalcButton(text = "1", modifier = Modifier.size(buttonSize))
                CalcButton(text = "2", modifier = Modifier.size(buttonSize))
                CalcButton(text = "3", modifier = Modifier.size(buttonSize))
                CalcButton(text = "-", modifier = Modifier.size(buttonSize), color = colorResource(id = R.color.OperatorsColor))
            }
            // Fila 5
            Row(
                modifier = Modifier.padding(bottom = 25.dp),
                horizontalArrangement = Arrangement.spacedBy(buttonPadding)
            ) {
                CalcButton(text = "AC", modifier = Modifier.size(buttonSize), color = colorResource(id = R.color.BackspaceColor))
                CalcButton(text = "0", modifier = Modifier.size(buttonSize))
                CalcButton(text = ".", modifier = Modifier.size(buttonSize), color = colorResource(id = R.color.ParenthesisColor))
                CalcButton(text = "=", modifier = Modifier.size(buttonSize), color = colorResource(id = R.color.OperatorsColor))
            }
        }
    }
}

@Composable
fun CalcButton(text: String, modifier: Modifier = Modifier, color: Color = Color.Gray) {
    Button(
        onClick = { /* Placeholder, no funcional */ },
        shape = CircleShape, // Redondeado
        colors = ButtonDefaults.buttonColors(containerColor = color),
        modifier = modifier
            .shadow(elevation = 7.dp, shape = CircleShape) // Añadir sombra con elevación leve
            .border(width = 2.dp, color = Color.White, shape = CircleShape) // Añadir borde blanco
    ) {
        Text(
            text = text,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            fontSize = 24.sp
        )
    }
}

@Preview(showBackground = true)
@Composable
fun CalculatorPreview() {
    CalculatorTheme {
        CalculatorScreen()
    }
}
